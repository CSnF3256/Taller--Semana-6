import javax.swing.*;

public class Lista {

    public Nodo inicio;
    public int tam;

    public Lista() {
        inicio = null;
        tam=0;
    }

    public void mostrarlista (JTextArea txtContenedor ){
        if (inicio==null){
            txtContenedor.setText("Lista Vacia");
        } else{
            StringBuilder listaStr = new StringBuilder();
            //creo un nuevo nodo en donde guaradremos los datos de inicio
            Nodo actual = inicio;
            while(actual!=null){
                listaStr.append(actual.dato)
                        .append("\n");
                actual = actual.sig;
            }
            txtContenedor.setText(listaStr.toString());
        }
    }


    public void actualizarContenedor (JTextArea txtContenedor){
        mostrarlista(txtContenedor);
    }

    public void ordenarBurbuja (JTextArea txtContenedor){
        if (inicio==null||inicio.sig == null){
            return;
        }

        boolean burbujear;
        do{
            burbujear = false;
            Nodo actual = inicio;
            Nodo sig  = inicio.sig;
            while(sig!=null){

                if(actual.dato > sig.dato) {
                    int temp = actual.dato;


                    actual.dato = sig.dato;
                    sig.dato=temp;
                    burbujear = true;
                }
                actual= sig;
                sig = sig.sig;
            }
        } while(burbujear);
        actualizarContenedor(txtContenedor);
    }

    //convertir arreglo
    public int [] convertirarray (){
        int []array = new int[tam];
        Nodo actual = inicio;
        int i=0;
        while (actual!=null){
            array [i++] = actual.dato;
            actual= actual.sig;
        }
        return array;
    }

    public void agregar ( int dato, JTextArea txtCont){
        Nodo nuevoNodo = new Nodo(dato);
        if(inicio==null){
            inicio = nuevoNodo;
        } else {
            Nodo actual = inicio;
            while (actual.sig!=null) {
                actual = actual.sig;
            }
            actual.sig  = nuevoNodo;
        }
        tam++;
        actualizarContenedor(txtCont);
    }

    public boolean eliminar(int dato, JTextArea txtCont){
        if (inicio==null){
            JOptionPane.showMessageDialog(null, "Lista Vacia");
            return false;
        }

        if (inicio.dato ==dato){
            inicio = inicio.sig;
            tam --;
            actualizarContenedor(txtCont);
            return true;
        }

        Nodo actual = inicio;

        while (actual.sig != null && actual.sig.dato!=dato){
            actual = actual.sig;

        } if (actual.sig != null){
            actual.sig = actual.sig.sig;
            tam--;
            actualizarContenedor(txtCont);
            return true;
        }
        JOptionPane.showMessageDialog(null, "Elemento no encontrado");
        return false;
    }


    public int buscarLineal(int dato, JTextArea txtCont){
        Nodo actual =  inicio;
        int posicion = 0;
        while (actual!=null){
            if (actual.dato == dato){
                return posicion;
            }
            actual = actual.sig;
            posicion++;
        }
        return -1;
    }



    public int interpolada (int dato, JTextArea txtCont) {

        ordenarBurbuja(txtCont);
        int[]arreglo = convertirarray();
        int ini = 0, fin = tam-1;
        while(ini<=fin && dato >= arreglo[ini] && dato<= arreglo[fin]){
            int posicion = ini+((dato-arreglo[ini])*(fin-ini)/arreglo[fin]-arreglo[ini]); // formula para saber posicion
            if (arreglo[posicion] ==dato){
                return posicion;
            }
            if(arreglo [posicion]<dato){
                ini = posicion+1;
            } else {fin = posicion-1;}

        }
        return -1;

    }

    public static class BusquedaSubcadenas {
        public static int buscar(String cadena, String subcadena) {
            int n = cadena.length();
            int m = subcadena.length();

            for (int i = 0; i <= n - m; i++) {
                int j;
                for (j = 0; j < m; j++) {
                    if (cadena.charAt(i + j) != subcadena.charAt(j)) break;
                }
                if (j == m) return i;
            }
            return -1;
        }
    }



    public void buscarSubcadenaEnLista(String subcadena, JTextArea txtCont) {
        Nodo actual = inicio;
        int posicion = 0;
        boolean encontrado = false;
        StringBuilder resultado = new StringBuilder();

        while (actual != null) {
            String datoComoTexto = String.valueOf(actual.dato);
            if (datoComoTexto.contains(subcadena)) {
                resultado.append("Dato: ").append(datoComoTexto)
                        .append(" en posición de la lista: ").append(posicion).append("\n");
                encontrado = true;
            }
            actual = actual.sig;
            posicion++;
        }

        if (encontrado) {
            txtCont.setText(resultado.toString());
        } else {
            txtCont.setText("Subcadena no encontrada en ningún nodo.");
        }
    }

}





