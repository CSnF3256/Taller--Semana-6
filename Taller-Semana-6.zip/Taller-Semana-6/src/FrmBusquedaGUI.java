import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class FrmBusquedaGUI {
    private JPanel pGeneral;
    private JButton buscarCadenaButton;
    private JTextField txtElemento;
    private JButton agregarButton;
    private JButton eliminarButton;
    private JButton ordenarButton;
    private JButton buscarLinealButton;
    private JButton buscarInterpolarButton;
    private JTextArea txtResultado;
    private JButton mostrarButton;
    private JButton buscarSubCadenaEnListaButton;
    private JTextArea subcadenas;

    Lista lista = new Lista();

    public static void main(String[] args) {
        JFrame frame = new JFrame("Buscador en Lista");
        frame.setContentPane(new FrmBusquedaGUI().pGeneral);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }

    public FrmBusquedaGUI() {
        agregarButton.addActionListener(e -> {
            try {
                int valor = Integer.parseInt(txtElemento.getText());
                lista.agregar(valor, txtResultado);
                txtElemento.setText("");
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(null, "Ingrese un número válido");
            }
        });

        eliminarButton.addActionListener(e -> {
            try {
                int valor = Integer.parseInt(txtElemento.getText());
                lista.eliminar(valor, txtResultado);
                txtElemento.setText("");
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(null, "Ingrese un número válido");
            }
        });

        ordenarButton.addActionListener(e -> {
            lista.ordenarBurbuja(txtResultado);
            JOptionPane.showMessageDialog(null, "Lista ordenada correctamente.");
        });

        //mostrarButton.addActionListener(e -> lista.mostrarlista(txtResultado));

        /*buscarLinealButton.addActionListener(e -> {
            try {
                int valor = Integer.parseInt(txtElemento.getText());
                int posicion = lista.buscarLineal(valor, txtResultado);
                mostrarResultadoBusqueda(posicion);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(null, "Ingrese un número válido");
            }
        });*/

       /* buscarInterpolarButton.addActionListener(e -> {
            try {
                int valor = Integer.parseInt(txtElemento.getText());
                int posicion = lista.interpolada(valor, txtResultado);
                mostrarResultadoBusqueda(posicion);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(null, "Ingrese un número válido");
            }
        });*/

        buscarCadenaButton.addActionListener(e -> {
            String cadena = JOptionPane.showInputDialog("Ingrese la cadena:");
            String subcadena = JOptionPane.showInputDialog("Ingrese la subcadena a buscar:");
            int pos = Lista.BusquedaSubcadenas.buscar(cadena, subcadena);
            if (pos != -1) {
                JOptionPane.showMessageDialog(null, "Subcadena encontrada en la posición " + pos);
            } else {
                JOptionPane.showMessageDialog(null, "Subcadena no encontrada");
            }
        });


        buscarSubCadenaEnListaButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String subcadena = txtElemento.getText();
                if (!subcadena.isEmpty()) {
                    lista.buscarSubcadenaEnLista(subcadena, subcadenas);
                } else {
                    JOptionPane.showMessageDialog(null, "Ingrese una subcadena para buscar");
                }
            }
        });
    }

    private void mostrarResultadoBusqueda(int posicion) {
        if (posicion == -1) {
            JOptionPane.showMessageDialog(null, "Elemento no encontrado");
        } else {
            JOptionPane.showMessageDialog(null, "Elemento encontrado en la posición: " + posicion);
        }
    }
}
